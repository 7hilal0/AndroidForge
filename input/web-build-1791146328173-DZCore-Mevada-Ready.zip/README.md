# DZCore Android WebView

A lightweight native Android WebView app for https://dzcore.top.

Behavior:
- dzcore.top and its subdomains stay inside the app.
- External main-frame links show an "إعلان" dialog.
- The X button closes the dialog.
- "متابعة الرابط" opens the external URL in the device browser.
- JavaScript, DOM storage and cookies are enabled for the website.

Build:
- Android Gradle Plugin 8.6.1
- compileSdk 35
- minSdk 23
- No AndroidX/AppCompat dependency is required.
